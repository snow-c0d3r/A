package com.cg.hbms.ui;

import java.util.Scanner;
import com.cg.hbms.service.AdminService;
import com.cg.hbms.service.AdminServiceImpl;

public class Ui {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int mainOption;
		char mainChoice='y';
		System.out.println("----------------WELCOME TO HBMS----------------");
		while(mainChoice=='y')
		{
			System.out.println("\n1. Login as Customer"
					+ "\n2. Login as Hotel Employee"
					+ "\n3. Login as Admin"
					+ "\n4. New user? Register"
					+ "\n5. Exit"
					+ "\n\nSelect option: ");
			mainOption=sc.nextInt();
			switch(mainOption)
			{
			case 1:
				System.out.println("User Login coming soon...");
				break;
			case 2:
				System.out.println("Hotel Employee Login coming soon...");
				break;
			case 3:
				char adminLoginChoice='y';
				AdminService adminService= new AdminServiceImpl();
				while(adminLoginChoice=='y')
				{
					System.out.println("Enter Admin User ID: ");
					String strAdminId =sc.next();
					System.out.println("Enter Admin password: ");
					String adminPassword=sc.next();
					sc.nextLine();
					if(adminService.authenticate(strAdminId,adminPassword))
					{
						System.out.println("Login Successful");
						int adminOption;
						char adminChoice='y';
						System.out.println("\n\t-----WELCOME ADMIN-----\nPlease select on option:\n");
						while(adminChoice=='y')
						{
							System.out.println("1. Add Hotel\n"
									+ "2. Delete Hotel\n"
									+ "3. Add Room\n"
									+ "4. Delete Room\n"
									+ "5. View List of Hotels\n"
									+ "6. View Bookings for a spcific hotel\n"
									+ "7. View Bookings of a specific date\n"
									+ "8. Exit"
									+ "Enter choice (1-9) : ");
							adminOption = sc.nextInt();
							String strHotelId;
							String hotelName;
							String hotelCity;
							String hotelAddress;
							String hotelDescription;
							String strHotelAvgRatePerNight;
							String hotelPhone1;
							String hotelPhone2;
							String strHotelRating;
							String hotelEmail;
							String roomType;
							String strPerNightRate;
							String RoomNo;
							String strDate;
							switch(adminOption){
							case 1:
								System.out.println("Enter Hotel Name : ");
								hotelName=sc.nextLine();
								sc.nextLine();
								System.out.println("Enter City : ");
								hotelCity=sc.nextLine();
								System.out.println("Enter Hotel Address : ");
								hotelAddress=sc.nextLine();
								System.out.println("Enter Discription : ");
								hotelDescription=sc.nextLine();
								System.out.println("Enter Average Rate per night : ");
								strHotelAvgRatePerNight=sc.nextLine();
								System.out.println("Hotel Phone Number : ");
								hotelPhone1=sc.nextLine();
								System.out.println("Alternate Phone Number : ");
								hotelPhone2=sc.nextLine();
								System.out.println("Hotel Rating : ");
								strHotelRating=sc.nextLine();
								System.out.println("Hotel Email ID : ");
								hotelEmail=sc.nextLine();
								System.out.println(adminService.addHotel(hotelName, hotelCity, hotelAddress, hotelDescription, strHotelAvgRatePerNight, hotelPhone1, hotelPhone2, strHotelRating, hotelEmail));
								break;
								
							case 2:
								System.out.println("Enter Hotel ID : ");
								strHotelId = sc.next();
								System.out.println(adminService.delHotel(strHotelId));
								break;
								
							case 3:
								System.out.println("Enter Hotel ID : ");
								strHotelId = sc.nextLine();
								sc.nextLine();
								System.out.println("Enter Room Number");
								RoomNo=sc.nextLine();
								System.out.println("Enter Room Type (Ac / NonAc) : ");
								roomType = sc.nextLine();
								System.out.println("Enter Rate per night : ");
								strPerNightRate = sc.nextLine();
								System.out.println(adminService.addRoom(strHotelId,RoomNo,roomType,strPerNightRate));
								break;
							case 4:
								System.out.println("Enter Hotel ID: ");
								strHotelId=sc.next();
								System.out.println(adminService.delRoom(strHotelId));
								break;
							case 5:
								System.out.println("***List of Hotels***\n"+adminService.viewListOfHotels());
								break;
							case 6:
								System.out.println("Enter Hotel ID: ");
								strHotelId=sc.next();
								if(adminService.viewBookingsByHotel(strHotelId).isEmpty())
								{
									System.out.println("No bookings found for given Hotel ID "+strHotelId);
								}
								else
								{
									System.out.println("Bookings for Hotel ID: "+strHotelId);
									System.out.println(adminService.viewBookingsByHotel(strHotelId));
								}
								break;
							case 7:
								System.out.println("Enter Date (yyyy-m-d) : ");
								strDate = sc.next();
								if(adminService.viewBookingsByDate(strDate).isEmpty())
								{
									System.out.println("No Bookings founf for given Date "+strDate);
								}
								else
								{
									System.out.println("Bookings for Date "+strDate);
									System.out.println(adminService.viewBookingsByDate(strDate));
								}
								
								break;
							case 8:
								break;
							default :
									
						}
					}
						}
				else
				{
					System.out.println("Invalid Login Credentials!..Try Again");
				}
				}
				
				break;
			case 4:
				System.out.println("Registeration page coming soon...");
				break;
			case 5:
				System.out.println("Thank you");
				mainChoice='n';
				break;
			default:
				System.out.println("Invalid Selection!! Select Again\n");
				break;
			}
		}
		
	}

}
